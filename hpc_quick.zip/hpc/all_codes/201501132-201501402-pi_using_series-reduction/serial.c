/*

 serial implementation of QuickSort

Authors: Mauli shah       201501132
	 Ekta Bhoraniya   201501402

*/
#include<stdio.h>
#include<math.h>
#include<omp.h>
#include<time.h>
#include<string.h>
#include<stdlib.h>

#define CLK CLOCK_MONOTONIC
int k=0;

/* Function to compute the difference between two points in time */

struct timespec diff(struct timespec start, struct timespec end);


struct timespec diff(struct timespec start, struct timespec end){
	struct timespec temp;
	if((end.tv_nsec-start.tv_nsec)<0){
		temp.tv_sec = end.tv_sec-start.tv_sec-1;
		temp.tv_nsec = 1000000000+end.tv_nsec-start.tv_nsec;
	}
	else{
		temp.tv_sec = end.tv_sec-start.tv_sec;
		temp.tv_nsec = end.tv_nsec-start.tv_nsec;
	}
	return temp;
}

/* This function takes one element as pivot, places
   the pivot element at its correct position in sorted
    array, and places all smaller (smaller than pivot)
   to left of pivot and all greater elements to right
   of pivot */

int partition(int arr[], int low_index, int high_index)
{
	int i, j, tmp, pivot;
	pivot = arr[low_index]; //pivot element
	i= low_index + 1;
	j= high_index;
	while(1)
	{
	while(i < high_index && pivot >= arr[i])
	    	i++;
	while(pivot < arr[j])
	    	j--;
		if(i < j)	// set elements greater than pivot after pivot
		{
		tmp = arr[i];
		arr[i] = arr[j];
		arr[j] = tmp;
		}
		else		// set elements smaller than pivot before pivot
		{
		tmp= arr[low_index];
		arr[low_index] = arr[j];
		arr[j]= tmp;
		return(j);
		}
	}
}

//function quick sort which divides array into two parts and recusively sort sub-arrays
void quicksort(int arr[], int low_index, int high_index)
{
int j;

	if(low_index < high_index)
	{
	j = partition(arr, low_index, high_index);	//takes index of pivot
       	quicksort(arr, low_index, j - 1); 		//sort sub-array having elements smaller than pivot
	quicksort(arr, j + 1, high_index);    		//sort sub-array with elements greater than pivot
	}
	
}

//main functionto start execution
int main(int argc, char* argv[])
{
	struct timespec start_e2e, end_e2e, start_alg, end_alg, e2e, alg;

/*	clock to calculate total time start	*/
	clock_gettime(CLK, &start_e2e);

	/* Check if enough command-line arguments are taken in. */
	if(argc < 3){
		printf( "Usage: %s n p \n", argv[0] );
		return -1;
	}

	int n=atoi(argv[1]);	/* size of input array */
	int p=atoi(argv[2]);	/* number of processors*/
	char *problem_name = "pi_using_series";//to run using Let's HPC folder
	char *approach_name = "reduction";
  	
/*      to take input from file      */
	char* filename =malloc(20);
  	strcpy(filename,"i_");
  	strcat(filename,argv[1]);
	strcat(filename,".txt");
	FILE *inp;
     	inp = fopen(filename, "r");
	int array[n];
 	int i;
 	
/*	Taking inputs from the file into array	*/
 	for (i = 0; i < n; i++)
          {
               	fscanf(inp, "%d\n", &array[i]);
          }

/*	Algo timer start	*/
	clock_gettime(CLK, &start_alg);	

/*----------------------Core algorithm starts here----------------------------------------------*/

	quicksort(array, 0, n - 1);

/*----------------------Core algorithm ends here----------------------------------------------*/

	clock_gettime(CLK, &end_alg);	//algo timer ends
	clock_gettime(CLK, &end_e2e);	//clock to calculate total time ends
	e2e = diff(start_e2e, end_e2e);
	alg = diff(start_alg, end_alg);

/*	prints problem name, approach name, time taken for algo and total taken time 	*/

	printf("Quick Sort , Divide and Conquer ,%d,%d,%ld,%ld,%ld,%ld\n", n, p, e2e.tv_sec, e2e.tv_nsec, alg.tv_sec, alg.tv_nsec);
        return 0;
}
