/*

 parallel implementation of QuickSort

Authors: Mauli shah       201501132
	 Ekta Bhoraniya   201501402

*/
#include<stdio.h>
#include<math.h>
#include<omp.h>
#include<time.h>
#include<string.h>
#include<stdlib.h>
 
#define CLK CLOCK_MONOTONIC
int k=0;

/* Function to compute the difference between two points in time */
struct timespec diff(struct timespec start, struct timespec end);
void quickSort_parallel(int* array, int lenArray, int numThreads);
void quickSort_parallel_internal(int* array, int left, int right, int cutoff);

struct timespec diff(struct timespec start, struct timespec end){
	struct timespec temp;
	if((end.tv_nsec-start.tv_nsec)<0){
		temp.tv_sec = end.tv_sec-start.tv_sec-1;
		temp.tv_nsec = 1000000000+end.tv_nsec-start.tv_nsec;
	}
	else{
		temp.tv_sec = end.tv_sec-start.tv_sec;
		temp.tv_nsec = end.tv_nsec-start.tv_nsec;
	}
	return temp;
}


void quickSort_parallel(int* array, int lenArray, int numThreads){

	int cutoff = 1000;

	#pragma omp parallel num_threads(numThreads)
	{	
		#pragma omp single nowait
		{
			quickSort_parallel_internal(array, 0, lenArray-1, cutoff);	
		}
	}	

}

/* This function takes one element as pivot, places
   the pivot element at its correct position in sorted
    array, and places all smaller (smaller than pivot)
   to left of pivot and all greater elements to right
   of pivot */
void quickSort_parallel_internal(int* array, int left, int right, int cutoff) 
{
	
	int i = left, j = right;
	int tmp;
	int pivot = array[(left + right) / 2];  	//pivot element

	
	{
	  	/* PARTITION PART  same as serial */
		while (i <= j) {
			while (array[i] < pivot)
				i++;
			while (array[j] > pivot)
				j--;
			if (i <= j) {
				tmp = array[i];
				array[i] = array[j];		//swaps elements with pivot to sort
				array[j] = tmp;
				i++;
				j--;
			}
		}

	}


	if ( ((right-left)<cutoff) )	// if array size is less than 1000 than sort it serially
	{
		if (left < j){ quickSort_parallel_internal(array, left, j, cutoff); }			
		if (i < right){ quickSort_parallel_internal(array, i, right, cutoff); }

	}
	else		//for large inputs divides task among threads
	{
		#pragma omp task 	
		{ quickSort_parallel_internal(array, left, j, cutoff); }
		#pragma omp task 	
		{ quickSort_parallel_internal(array, i, right, cutoff); }		
	}

}

// main function  to start execution
int main(int argc, char* argv[])
{
	struct timespec start_e2e, end_e2e, start_alg, end_alg, e2e, alg;

/*	clock to calculate total time start	*/
	clock_gettime(CLK, &start_e2e);

	/* Check if enough command-line arguments are taken in. */
	if(argc < 3){
		printf( "Usage: %s n p \n", argv[0] );
		return -1;
	}

	int n=atoi(argv[1]);	/* size of input array */
	int p=atoi(argv[2]);	/* number of processors*/
	char *problem_name = "pi_using_series";	//to run using Let's HPC folder
	char *approach_name = "reduction";
  	
/*      to take input from file      */
	char* filename =malloc(20);
  	strcpy(filename,"i_");
  	strcat(filename,argv[1]);
	strcat(filename,".txt");
	FILE *inp;
     	inp = fopen(filename, "r");
	int array[n];
 	int i;
 	
/*	Taking inputs from the file into array	*/
 	for (i = 0; i < n; i++)
          {
               	fscanf(inp, "%d\n", &array[i]);
          }

/*	Algo timer start	*/
	clock_gettime(CLK, &start_alg);	
      
/*----------------------Core algorithm starts here----------------------------------------------*/
	
	quickSort_parallel(array, n ,p);

/*----------------------Core algorithm ends here----------------------------------------------*/
	
	clock_gettime(CLK, &end_alg);	//algo timer ends
	clock_gettime(CLK, &end_e2e);	//clock to calculate total time ends
	e2e = diff(start_e2e, end_e2e);
	alg = diff(start_alg, end_alg);

/*	prints problem name, approach name, time taken for algo and total taken time 	*/
	printf("Quick Sort , Divide and Conquer ,%d,%d,%ld,%ld,%ld,%ld\n",  n, p, e2e.tv_sec, e2e.tv_nsec, alg.tv_sec, alg.tv_nsec);
        return 0;
}
