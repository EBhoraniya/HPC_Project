python main_script_without_perf.py $1
python collect_data_without_perf.py
python txt_to_csv.py
